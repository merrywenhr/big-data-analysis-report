# 1．文件“中医病症.xlsx”中存储了1000个病人的症状信息，请采用Apriori算法对病症进行分析，挖掘病症之间的关联关系。（20分）
# (1)	采用apyori库来进行挖掘；
# (2)	采用mlxtend库来进行挖掘；
# (3)	分析、比较(1)、(2)的结果是否相同，并讨论最小支持度、最小置信度等参数的设置对算法结果的影响。

import pandas as pd
from apyori import apriori
from mlxtend.frequent_patterns import association_rules
from mlxtend.preprocessing import TransactionEncoder

# 显示所有列
pd.set_option('display.max_columns', None)

# 加载数据集
file_path = '../../data/中医病症.xlsx'
data = pd.read_excel(file_path)
# print(data.head(5))

# 将每个病人的症状列表转换为列表形式
data['病人症状'] = data['病人症状'].apply(lambda x: x.split(','))
# print(data)
# print(data['病人症状'])


# # (1)	采用apyori库来进行挖掘；
#
# # 使用apyori库进行关联规则挖掘
# min_support = 0.02  # 最小支持度，我们只关注至少出现在20个病人记录中的症状组合
# min_confidence = 0.4  # 最小置信度 只关注那些在前件发生时后件发生概率至少为40%的规则
# min_lift = 1.0  # 最小提升度 只关注那些存在正相关关系的规则
#
# association_rules = apriori(data['病人症状'], min_support=min_support, min_confidence=min_confidence, min_lift=min_lift)
# association_results = list(association_rules)
# # print(association_results)
#
# # 提取规则结果
# apyori_results = []
# for item in association_results:
#     pair = item[0]
#     items = [x for x in pair]
#     apyori_results.append({
#         'Items': ','.join(items),
#         'Support': item[1],
#         'Confidence': item[2][0][2],
#         'Lift': item[2][0][3]
#     })
#
# apyori_df = pd.DataFrame(apyori_results)
# # print(apyori_df)
# # apyori_df.to_excel('apyori_results.xlsx')


# (2)	采用mlxtend库来进行挖掘；

# 使用mlxtend库进行关联规则挖掘
te = TransactionEncoder()
te_ary = te.fit(data['病人症状']).transform(data['病人症状'])
# print(te_ary)
df = pd.DataFrame(te_ary, columns=te.columns_)
# print(df)

# 计算频繁项集
min_support = 0.02
min_confidence = 0.4

frequent_itemsets = apriori(df, min_support=min_support, use_colnames=True)

# 确保频繁项集是DataFrame
frequent_itemsets = pd.DataFrame(frequent_itemsets)

# 将 'items' 列重命名为 'itemsets'
frequent_itemsets.rename(columns={'items': 'itemsets'}, inplace=True)

# 检查频繁项集的列
# print(frequent_itemsets.columns)

# 计算关联规则
rules = association_rules(frequent_itemsets, metric="confidence", min_threshold=min_confidence)
# print(rules)
# print(rules.columns)
# 'antecedents':规则的前件（也称为左部），表示“如果...”
# 'consequents':规则的后件（也称为右部），表示“那么...”。
# 'antecedent support':前件出现的支持度，即前件在所有交易中出现的频率
# 'consequent support':后件出现的支持度，即后件在所有交易中出现的频率
# 'support':规则的支持度，即前件和后件同时出现的频率
# 'confidence':规则的置信度，即在前件出现的条件下后件也出现的概率
# 'lift':规则的提升度，即前件和后件之间的关联强度
# 'leverage':规则的杠杆值，即前件和后件同时出现的频率与它们独立出现的频率之间的差异 杠杆值越大，关联关系越强。
# 'conviction':规则的确信度，即在前件出现的情况下后件不出现的概率的倒数
# 'zhangs_metric'

# 转换为DataFrame格式
mlxtend_df = pd.DataFrame(rules)
# print(mlxtend_df)

# 去除括号
mlxtend_df['antecedents'] = mlxtend_df['antecedents'].astype(str).str.replace('[frozenset({})]', '',
                                                                              regex=True).str.replace('[{}]',
                                                                                                      '',
                                                                                                      regex=True)
mlxtend_df['consequents'] = mlxtend_df['consequents'].astype(str).str.replace('[frozenset({})]', '',
                                                                              regex=True).str.replace('[{}]',
                                                                                                      '',
                                                                                                      regex=True)

# 去掉 'antecedents' 列中的单引号
mlxtend_df['antecedents'] = mlxtend_df['antecedents'].str.replace("'", "")

# 去掉 'consequents' 列中的单引号
mlxtend_df['consequents'] = mlxtend_df['consequents'].str.replace("'", "")

# print(mlxtend_df)
mlxtend_df.to_excel('mlxtend_results.xlsx')


