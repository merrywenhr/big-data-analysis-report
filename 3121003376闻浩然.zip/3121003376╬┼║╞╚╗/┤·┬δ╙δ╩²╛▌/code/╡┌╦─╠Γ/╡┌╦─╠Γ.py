# -*- coding: utf-8 -*-
# 4．	文件“data.csv”中存储了某地区1994年至2013年的财政收入y，以及财政收入y的影响因素x1（社会从业人数）, x2（在岗职工工资总额）,
# x3(社会消费品零售总额), x4（城镇居民人均可支配收入）, x5（城镇居民人均消费性支出）, x6（年末总人口）, x7（全社会固定资产投入额）,
# x8（地区生产总值）, x9（第一产业产值）, x10（税收）, x11（居民消费价格指数）, x12（第三产业与第二产业产值比）, x13（居民消费水平）的相关数据。
# 请编写程序完成以下问题：（20分）
# (1)	对上述数据进行描述性统计分析；
# (2)	对上述数据进行相关性分析，找出属性之间的“多重共线性”与“完全共线性”；
# (3)	采用Lasso回归方法处理(2)中的“多重共线性”与“完全共线性”，从x1, x2, ..., x13中选择出关键属性（降维）。假设降维之后的关键属性为x1, x2, x4,
# x5, x8 , x12。
# (4)	从data.csv中读取x1, x2, x4, x5, x8 , x12的值，调用灰色预测方法GM11.py分别预测2014年、2015年的x1, x2, x4, x5, x8 , x12值并保存；
# (5)	将(4)中求得的结果代入支持向量机预测模型SVR，求取1994年至2015年财政收入的预测值并保存，并绘图比较预测值与实际值，进而评价SVR模型的预测效果。

import pandas as pd
from statsmodels.stats.outliers_influence import variance_inflation_factor
from sklearn.linear_model import Lasso
from sklearn.preprocessing import StandardScaler
import numpy as np
# 导入GM11.py中的函数
from GM11 import GM11
from sklearn.svm import SVR, LinearSVR
from sklearn.model_selection import train_test_split
from sklearn.model_selection import GridSearchCV
import matplotlib.pyplot as plt
from sklearn.metrics import mean_squared_error

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']  # 指定默认字体
plt.rcParams['axes.unicode_minus'] = False  # 解决保存图像是负号'-'显示为方块的问题

# 显示所有列
pd.set_option('display.max_columns', None)

# (1)	对上述数据进行描述性统计分析；

df = pd.read_csv('../../data/data.csv')

# 执行描述性统计分析
description = df.describe()

# 打印结果
# print(description)

# (2)	对上述数据进行相关性分析，找出属性之间的“多重共线性”与“完全共线性”；
# 使用vif判断共线性
# 计算每个特征的VIF值
x = df.drop(columns=['y'])  # 去除目标变量
vif_data = pd.DataFrame()
vif_data["feature"] = x.columns
vif_data["VIF"] = [variance_inflation_factor(x.values, i) for i in range(x.shape[1])]
# print(vif_data)


# (3)	采用Lasso回归方法处理(2)中的“多重共线性”与“完全共线性”，从x1, x2, ..., x13中选择出关键属性（降维）。假设降维之后的关键属性为x1, x2, x4,
# x5, x8 , x12。
x1 = df.drop(columns=['y'])
y = df['y']

scaler = StandardScaler()
x1_scaled = scaler.fit_transform(x1)

lasso = Lasso(alpha=0.1)
lasso.fit(x1_scaled, y)

# 计算系数
lasso_coefficients = pd.DataFrame({
    '变量': x1.columns,
    '系数': lasso.coef_
}).sort_values(by='系数', ascending=False)
# print(lasso_coefficients)

# 计算系数的绝对值
lasso_coefficients['绝对值'] = lasso_coefficients['系数'].abs()
# 按绝对值排序并选取前8个特征作为关键属性
top8_features = lasso_coefficients.sort_values(by='绝对值', ascending=False).head(8)
# print(top8_features)

# (4)	从data.csv中读取x1, x2, x4, x5, x8 , x12的值，调用灰色预测方法GM11.py分别预测2014年、2015年的x1, x2, x4, x5, x8 , x12值并保存；
# 根据三的结果我们选取'x1', 'x2', 'x3', 'x4', 'x5', 'x6', 'x7', 'x13'作为关键属性

selected_columns = ['x1', 'x2', 'x3', 'x4', 'x5', 'x6', 'x7', 'x13']
data_selected = df[selected_columns]
# print(data_selected)

# 预测未来的值
predicted_values = {}
for column in selected_columns:
    model = GM11(data_selected[column].values)
    predicted_2014 = model[0](len(data_selected) + 1)
    predicted_2015 = model[0](len(data_selected) + 2)
    predicted_values[column] = [predicted_2014, predicted_2015]

# 将预测值转换为DataFrame
predicted_df = pd.DataFrame(predicted_values)
# print(predicted_df)

# (5)	将(4)中求得的结果代入支持向量机预测模型SVR，求取1994年至2015年财政收入的预测值并保存，并绘图比较预测值与实际值，进而评价SVR模型的预测效果。

# 准备训练数据
X = data_selected
y = df['y']
# print(X)
# print(y)

# 分割数据集
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# 训练模型
svr = LinearSVR()
svr.fit(X_train, y_train)

# 合并2014-2015年的数据 添加年份 修改nan为0
full_data = pd.concat([df, predicted_df])
full_data = full_data[['x1', 'x2', 'x3', 'x4', 'x5', 'x6', 'x7', 'x13', 'y']].reset_index(drop=True)
full_data['year'] = pd.Series(range(1994, 2016))
full_data.fillna(0, inplace=True)

# 模型预测
x_p = full_data[selected_columns]
y_predict = svr.predict(x_p)
# print(y_predict)

# 合并数据
full_data['predict'] = pd.Series(y_predict)
# print(full_data)

# 去除2014-2015年的数据
results = full_data[~full_data['year'].isin([2014, 2015])]
# print(results)

# # 绘图
# plt.figure(figsize=(10, 6))
# plt.plot(results['year'], results['y'], label='实际值', marker='o')
# plt.plot(results['year'], results['predict'], label='预测值', marker='x')
# plt.xlabel('年份')
# plt.ylabel('财政收入')
# plt.title('财政收入实际值与预测值比较')
# plt.xticks(results['year'])
# plt.legend()
# plt.show()
#
#
# 计算均方误差
mse = mean_squared_error(results['y'], results['predict'])
# print(f"均方误差: {mse}")
