# -*- coding: utf-8 -*-

# 2．XGBoost(Extreme Gradient Boosting，极致梯度提升树)是一种新兴的决策树优化算法,它在梯度提升决策树的基础上进行了进一步的改进和优化。
# 请查阅相关资料（如：https://xgboost.readthedocs.io）, 了解XGBoost原理，并编程完成以下问题。（20分）
# (1)文件“信用卡交易数据.xlsx”中存储了1000条客户信用卡的交易数据。其中特征变量有：换设备次数、支付失败次数、换IP次数、换IP国次数、交易金额。
# 目标变量是是否存在欺诈，若是盗用信用卡产生的交易则标记为1，代表欺诈，正常交易则标记为0。随机选择800条记录作为训练集、剩下200条记录作为测试集，
# 构建XGBoost预测模型，并绘制模型的ROC（Receiver Operating Characteristic curve）曲线，计算模型的AUC（Area Under Curve）值，对模型进行评估；
# (2)采用GridSearchCV方法进行模型参数调优，并对调优结果进行分析。

import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn import metrics
import matplotlib.pyplot as plt
from xgboost.sklearn import XGBClassifier, XGBRegressor
from sklearn.model_selection import GridSearchCV

data = pd.read_excel('../../data/信用卡交易数据.xlsx')
# print(data)

# 提取特征变量
X = data.drop(['欺诈标签'], axis=1)
y = data['欺诈标签']

# (1)
# 数据分割
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# 拟合模型
model = XGBClassifier()
model = model.fit(X_train, y_train)
y_predict = model.predict(X_test)
y_predict_proba = model.predict_proba(X_test)
fpr, tpr, thresholds = metrics.roc_curve(y_test, y_predict_proba[:, 1], pos_label=1)
roc_auc = metrics.auc(fpr, tpr)
# print('AUC:', roc_auc)
# # 绘图
# plt.figure()
# lw = 2
# plt.plot(
#     fpr,
#     tpr,
#     color="red",
#     lw=lw,
#     label="ROC curve (area = %0.2f)" % roc_auc,
# )
# plt.plot([0, 1], [0, 1], color="blue", lw=lw, linestyle="--")
# plt.xlim([0.0, 1.0])
# plt.ylim([0.0, 1.05])
# plt.xlabel("False Positive Rate")
# plt.ylabel("True Positive Rate")
# plt.title("Receiver operating characteristic curve")
# plt.legend(loc="lower right")
# plt.show()

# (2)采用GridSearchCV方法进行模型参数调优，并对调优结果进行分析。
# 调参的要旨是：每次调一个或两个超参数，然后将找到的最优超参数代入到模型中继续调余下的参数。
# 最佳迭代次数(树模型的个数)：n_estimators
# min_child_weight以及max_depth
# gamma
# subsample以及colsample_bytree
# reg_alpha以及reg_lambda
# learning_rate

xgb = XGBClassifier(learning_rate=0.01,
                    n_estimators=150,
                    max_depth=3,
                    min_child_weight=1,
                    gamma=0.5,
                    colsample_bytree=0.6,
                    subsample=1,
                    reg_alpha=0,
                    reg_lambda=0,
                    )
# 对min_child_weight以及max_depth调优
# param_test1 = {
#     'min_child_weight': [1, 3, 5, 7],
#     'max_depth': [3, 5, 6, 7, 9, 12, 15, 17, 25]
# }

# # 对gamma调优
# param_test2 = {
#     'gamma': [0, 0.05 , 0.1, 0.3, 0.5, 0.7, 0.9, 1]
# }

# # 对subsample以及colsample_bytree调优
# param_test3 = {
#     'subsample': [0.6, 0.7, 0.8, 0.9, 1],
#     'colsample_bytree': [0.6, 0.7, 0.8, 0.9, 1]
# }

# # 对reg_alpha以及reg_lambda调优
# param_test4 = {
#     'reg_alpha': [0, 0.01, 0.02, 0.03, 0.04, 0.05, 0.06, 0.07, 0.08, 0.09, 0.1, 1],
#     'reg_lambda': [0, 0.1, 0.5, 1]
# }

# # 对learning_rate调优
# param_test5 = {
#     '对learning_rate调优':[0.01, 0.015, 0.025, 0.05, 0.1]
# }

# xgb_res = GridSearchCV(estimator=xgb,
#                        param_grid=param_test5,
#                        n_jobs=4,
#                        cv=5)
#
# xgb_res.fit(X_train, y_train)
# print('gsearch1.grid_scores_', xgb_res.cv_results_)
# print('gsearch1.best_params_', xgb_res.best_params_)
# print('gsearch1.best_score_', xgb_res.best_score_)

# 使用调优完成的模型

xgb = xgb.fit(X_train, y_train)

y_modify_predict = xgb.predict(X_test)
y_modify_predict_proba = xgb.predict_proba(X_test)
fpr_modify, tpr_modify, thresholds_modify = metrics.roc_curve(y_test, y_modify_predict_proba[:, 1], pos_label=1)
roc_auc_modify = metrics.auc(fpr_modify, tpr_modify)

print('AUC_modify:', roc_auc_modify)
# 绘图
plt.figure()
lw = 2
plt.plot(
    fpr_modify,
    tpr_modify,
    color="red",
    lw=lw,
    label="ROC_modify curve (area = %0.2f)" % roc_auc_modify,
)
plt.plot([0, 1], [0, 1], color="blue", lw=lw, linestyle="--")
plt.xlim([0.0, 1.0])
plt.ylim([0.0, 1.05])
plt.xlabel("False Positive Rate")
plt.ylabel("True Positive Rate")
plt.title("Receiver operating characteristic curve")
plt.legend(loc="lower right")
plt.show()

