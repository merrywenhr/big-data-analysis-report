# -*- coding: utf-8 -*-

# (1)	数据探索分析：包括描述性统计分析、分布分析、相关性分析等。通过数据探索分析，得到了哪些有用的信息？（自由发挥）
# (2)	数据预处理：首先去除SUM_YR_1为空的记录，去除AGE>100的记录；然后保留SUM_YR_1为非零的、且SEG_KM_SUM>0，且AVG_DISCOUNT不为0的记录；
# (3)	RFMLC模型构建：在教材RFM模型基础上，增加L、C两个维度，构建RFMLC模型，提取这5个属性的对应值，并进行数据变换与标准化处理。
# 1）R：客户最近一次乘机距离观测窗口结束的月数。即：R=LAST_TO_END
# 2）F：客户在观测窗口内乘坐飞机的次数。即：F=FLIGHT_COUNT
# 3）M：客户在观测窗口内累计的飞行里程。即：M=SEG_KM_SUM
# 4）L： 会员入会时间距离观测窗口结束的月数。即：L=LOAD_TIME-FFP_DATE
# 5）C:  客户在观测窗口内的平均折扣率。即：C=AVG_DISCOUNT
# (4)	采用DBSCAN(Density-Based Spatial Clustering of Applications with Noise)对(3)中处理好的数据进行聚类，设获得的聚类数目为N，
# 求出每个类别中的客户数量，及每个类别的中心；
# (5)	采用Kmeans算法，设置类别数量为N，对(3)中处理好的数据进行聚类，采用轮廓系数法对Kmeans聚类的结果进行分析（当类别数量为N时，轮廓系数是否为最大？），
# 并分析、对比Kmeans算法得到的结果与(4)的结果是否存在较大差异？
# (6)	根据(4)、(5)的结果进行客户特征与价值分析，绘制客户分群雷达图，以此为依据，并结合你所学《管理学》与《市场营销》等课程相关知识，分析针对每类客户，
# 应该如何开展不同的个性化服务，从而实现效益最大化？

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
from sklearn.cluster import DBSCAN, KMeans
from sklearn.metrics import silhouette_score
from sklearn.preprocessing import StandardScaler

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']  # 指定默认字体
plt.rcParams['axes.unicode_minus'] = False  # 解决保存图像是负号'-'显示为方块的问题
# 显示所有列
pd.set_option('display.max_columns', None)

data = pd.read_csv('../../data/air_data.csv', encoding='GB18030')
# print(data.head())

# (1)	数据探索分析：包括描述性统计分析、分布分析、相关性分析等。通过数据探索分析，得到了哪些有用的信息？（自由发挥）

# print(data.describe())

# # 年龄分布
# plt.figure(figsize=(10, 6))
# sns.histplot(data['AGE'], bins=30, kde=True)
# plt.title('年龄分布')
# plt.xlabel('年龄')
# plt.ylabel('频数')
# plt.show()

# # 飞行次数与公里数相关性
# plt.figure(figsize=(10, 6))
# sns.scatterplot(x='FLIGHT_COUNT', y='SEG_KM_SUM', data=data)
# plt.title('飞行次数与公里数的关系')
# plt.xlabel('飞行次数')
# plt.ylabel('公里数')
# plt.show()

# 计算飞行次数与公里数之间的相关系数
correlation_FLIGHT_COUNT_SEG_KM_SUM = data[['FLIGHT_COUNT', 'SEG_KM_SUM']].corr()
# print(correlation_FLIGHT_COUNT_SEG_KM_SUM)

# # 折扣率分布
# plt.figure(figsize=(10, 6))
# sns.histplot(data['AVG_DISCOUNT'], bins=30, kde=True)
# plt.title('折扣率分布')
# plt.xlabel('折扣率')
# plt.ylabel('频数')
# plt.show()

# (2)	数据预处理：首先去除SUM_YR_1为空的记录，去除AGE>100的记录；然后保留SUM_YR_1为非零的、且SEG_KM_SUM>0，且AVG_DISCOUNT不为0的记录；

# 去除SUM_YR_1为空的记录
data_cleaned = data.dropna(subset=['SUM_YR_1'])

# 去除AGE>100的记录
data_cleaned = data_cleaned[data_cleaned['AGE'] <= 100]

# 保留SUM_YR_1为非零的、且SEG_KM_SUM>0，且AVG_DISCOUNT不为0的记录
data_cleaned = data_cleaned[
    (data_cleaned['SUM_YR_1'] != 0) &
    (data_cleaned['SEG_KM_SUM'] > 0) &
    (data_cleaned['AVG_DISCOUNT'] != 0)
    ]

# 重置索引
data_cleaned.reset_index(inplace=True, drop=True)
# data_cleaned.to_csv('data_cleaned.csv')

# # (3)
# 转换日期列为datetime格式，以便后续计算
data_cleaned['FFP_DATE'] = pd.to_datetime(data_cleaned['FFP_DATE'], format='%Y/%m/%d')
data_cleaned['LOAD_TIME'] = pd.to_datetime(data_cleaned['LOAD_TIME'], format='%Y/%m/%d')

# print(data_cleaned['FFP_DATE'])
# print(data_cleaned['LOAD_TIME'])

# 计算L（会员时长）：会员入会时间距离观测窗口结束的月数
data_cleaned['L'] = (data_cleaned['LOAD_TIME'].dt.year - data_cleaned['FFP_DATE'].dt.year) * 12 + (
        data_cleaned['LOAD_TIME'].dt.month - data_cleaned['FFP_DATE'].dt.month)

# print(data_cleaned['L'])

# 提取并计算各个维度值
data_cleaned['R'] = data_cleaned['LAST_TO_END']
data_cleaned['F'] = data_cleaned['FLIGHT_COUNT']
data_cleaned['M'] = data_cleaned['SEG_KM_SUM']
data_cleaned['C'] = data_cleaned['AVG_DISCOUNT']

# 选择所需的列
rfmlc_data = data_cleaned[['R', 'F', 'M', 'L', 'C']]

# 对数据进行标准化处理
scaler = StandardScaler()
rfmlc_data_scaled = pd.DataFrame(scaler.fit_transform(rfmlc_data), columns=rfmlc_data.columns)

# print(rfmlc_data_scaled)

# (4)	采用DBSCAN(Density-Based Spatial Clustering of Applications with Noise)对(3)中处理好的数据进行聚类，设获得的聚类数目为N，
# 求出每个类别中的客户数量，及每个类别的中心；

# 使用DBSCAN进行聚类
dbscan = DBSCAN(eps=0.5, min_samples=5)
dbscan_data_scaled = rfmlc_data_scaled.copy()
dbscan_data_scaled['cluster'] = dbscan.fit_predict(dbscan_data_scaled)
dbscan_data_scaled.to_csv('dbscan_data_scaled.csv')
# print(dbscan_data_scaled)

# 计算每个类别的客户数量
dbscan_cluster_counts = dbscan_data_scaled['cluster'].value_counts()
# print(dbscan_cluster_counts)
# 计算每个类别的中心
dbscan_cluster_centers = dbscan_data_scaled.groupby('cluster').mean()
# print(dbscan_cluster_centers)

# (5)	采用Kmeans算法，设置类别数量为N，对(3)中处理好的数据进行聚类，采用轮廓系数法对Kmeans聚类的结果进行分析（当类别数量为N时，轮廓系数是否为最大？），
# 并分析、对比Kmeans算法得到的结果与(4)的结果是否存在较大差异？

# KMeans聚类 使用（4）的N值
kmeans = KMeans(n_clusters=len(dbscan_cluster_counts), random_state=42)
kmeans_data_scaled = rfmlc_data_scaled.copy()
kmeans_data_scaled['cluster'] = kmeans.fit_predict(kmeans_data_scaled)

# kmeans_data_scaled.to_csv('kmeans_data_scaled.csv')
# print(kmeans_data_scaled)

# # 轮廓系数法
# def score_scatterplot(kmeans_data, k):
#     score = []
#     for i in range(2, k + 1):
#         kmeans_scatterplot = KMeans(n_clusters=i, random_state=42)
#         kmeans_data_scaled_scatterplot = kmeans_data.copy()
#         kmeans_data_scaled_scatterplot['cluster'] = kmeans_scatterplot.fit_predict(kmeans_data_scaled_scatterplot)
#         # 计算轮廓系数
#         silhouette_avg_scatterplot = silhouette_score(kmeans_data, kmeans_data_scaled_scatterplot['cluster'])
#         score.append(silhouette_avg_scatterplot)
#     return score
#
#
# print(score_scatterplot(rfmlc_data_scaled, len(dbscan_cluster_counts)))

# # 计算轮廓系数
silhouette_avg = silhouette_score(rfmlc_data_scaled, kmeans_data_scaled['cluster'])
# print(silhouette_avg)  # 0.20735714876305014

# # 计算KMeans聚类结果中的每个类别的客户数量和中心
kmeans_cluster_counts = kmeans_data_scaled['cluster'].value_counts()
# print(kmeans_cluster_counts)
kmeans_cluster_centers = kmeans_data_scaled.groupby('cluster').mean()


# print(kmeans_cluster_centers)

# (6)	根据(4)、(5)的结果进行客户特征与价值分析，绘制客户分群雷达图，以此为依据，并结合你所学《管理学》与《市场营销》等课程相关知识，分析针对每类客户，
# 应该如何开展不同的个性化服务，从而实现效益最大化？

# 雷达图
def plot_radar(radar_data, title):
    labels = radar_data.columns
    num_vars = len(labels)

    angles = np.linspace(0, 2 * np.pi, num_vars, endpoint=False).tolist()
    angles += angles[:1]

    fig, ax = plt.subplots(figsize=(6, 6), subplot_kw=dict(polar=True))
    for i in range(len(radar_data)):
        values = radar_data.iloc[i].tolist()
        values += values[:1]
        ax.plot(angles, values, linewidth=1, linestyle='solid', label=f'Cluster {data.index[i]}')
        ax.fill(angles, values, alpha=0.25)

    ax.set_yticklabels([])
    ax.set_xticks(angles[:-1])
    ax.set_xticklabels(labels)
    plt.title(title)
    plt.legend(loc='upper right')
    plt.show()


plot_radar(dbscan_cluster_centers, "DBSCAN雷达图")
plot_radar(kmeans_cluster_centers, "KMeans雷达图")
