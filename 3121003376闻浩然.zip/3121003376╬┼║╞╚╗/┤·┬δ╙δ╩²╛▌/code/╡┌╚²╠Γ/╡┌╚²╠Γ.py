# -*- coding: utf-8 -*-

# 3．	基于皮尔逊相关系数的电影智能推荐：文件“电影.xlsx”中保存了9712部电影的信息，分为“电影编号”、“名称”、“类别”3个属性；文件“评分.xlsx”
# 中为9712部电影的100836条评分记录，分为“用户编号”、“电影编号”、“评分”3个属性。请依次完成以下问题。（20分）
# (1)	将“电影.xlsx”与“评分.xlsx”合并为一张表，保存在“电影推荐系统.xlsx”文件中，包含“电影编号”、“名称”、“类别”、“用户编号”、“评分”5个属性；
# (2)	数据探索分析：
#   1）统计分析每个得分的电影数量，并绘制直方图；
#   2）获取评分最高的5部电影，输出电影名称、评分；
#   3）获取评分次数最多的5部电影，输出电影名称、评分、评分次数；
# (3)将原始数据转换为数据透视表。以“用户编号”作为数据透视表的索引，即index参数为“用户编号”；设置columns参数为“名称”，即以电影名为数据透视表的列；
# 设置values参数为“评分”，即以电影评分作为数据透视表中显示的数据。输出该数据透视表的描述性统计信息；
# (4)从（3）中得到的数据透视表中提取各个用户对《肖申克的救赎（1994）》的评分，并计算《肖申克的救赎（1994）》与其他电影的皮尔逊相关系数，并去除其中
# 皮尔逊相关系数为0的记录，并将求得的结果与“评分次数”合并，形成一个新表，即表中包含“名称”、“相关系数”、“评分次数”3个属性，将皮尔逊相关系数最大的5部
# 电影输出，作为推荐给用户的电影。
# (5)分析（4）中求出的皮尔逊相关系数中，为何有些为0？

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']  # 指定默认字体
plt.rcParams['axes.unicode_minus'] = False  # 解决保存图像是负号'-'显示为方块的问题

movie_df = pd.read_excel('../../data/电影.xlsx')
score_df = pd.read_excel('../../data/评分.xlsx')
# print(movie_df)
# print(score_df)

# (1)	将“电影.xlsx”与“评分.xlsx”合并为一张表，保存在“电影推荐系统.xlsx”文件中，包含“电影编号”、“名称”、“类别”、“用户编号”、“评分”5个属性；

# 合并数据
mix_df = pd.merge(movie_df, score_df, on='电影编号')
# print(mix_df)

# 保存在“电影推荐系统.xlsx”文件中
# mix_df.to_excel('电影推荐系统.xlsx', index=False)

# (2)	数据探索分析：
# 1. 统计每个得分的电影数量，并绘制直方图

# 统计数量
score_counts = mix_df['评分'].value_counts().sort_index()
# print(score_counts)

# # 绘制直方图
# plt.figure(figsize=(8, 6))
# sns.histplot(data=mix_df, x='评分', bins=10, kde=False, color='salmon')
# plt.title('评分分布')
# plt.xlabel('评分')
# plt.ylabel('频率')
# plt.xticks(rotation=45)
# plt.grid(True)
# plt.show()

# 2. 获取评分最高的5部电影
average_score = mix_df.groupby('电影编号').agg({'评分': 'mean', '名称': 'first'}).sort_values(by='评分',
                                                                                              ascending=False)
top_5_score = average_score.head(5)[['名称', '评分']]

# print("评分最高的5部电影:")
# print(top_5_score)

# 3. 获取评分次数最多的5部电影
score_counts = mix_df.groupby('电影编号').agg({'评分': 'count', '名称': 'first'}).sort_values(by='评分',
                                                                                              ascending=False)
top_5_counts = score_counts.head(5).rename(columns={'评分': '评分次数'})[['名称', '评分次数']]

# print("评分次数最多的5部电影:")
# print(top_5_counts)

# (3)将原始数据转换为数据透视表。以“用户编号”作为数据透视表的索引，即index参数为“用户编号”；设置columns参数为“名称”，即以电影名为数据透视表的列；
# 设置values参数为“评分”，即以电影评分作为数据透视表中显示的数据。输出该数据透视表的描述性统计信息；

pivot_table = mix_df.pivot_table(index='用户编号', columns='名称', values='评分')
# print(pivot_table)
# print(type(pivot_table))

# 替换nan
pivot_table.fillna(0, inplace=True)
# print(pivot_table)

# 描述性信息
# print(pivot_table.describe())

# (4)从（3）中得到的数据透视表中提取各个用户对《肖申克的救赎（1994）》的评分，并计算《肖申克的救赎（1994）》与其他电影的皮尔逊相关系数，并去除其中
# 皮尔逊相关系数为0的记录，并将求得的结果与“评分次数”合并，形成一个新表，即表中包含“名称”、“相关系数”、“评分次数”3个属性，将皮尔逊相关系数最大的5部
# 电影输出，作为推荐给用户的电影。

# 肖申克救赎评分
shawshank_score = pivot_table['肖申克的救赎（1994）']
# print(shawshank_score)

# 计算皮尔逊相关系数
correlation = pivot_table.corrwith(shawshank_score)
# print(correlation)

# 去除0值
correlation = correlation[correlation != 0]
# print(correlation)

# 评分次数
score__counts2 = pivot_table.notna().sum()

# 合并新表
correlation_df = pd.DataFrame({
    '名称': correlation.index,
    '相关系数': correlation.values,
    '评分次数': score__counts2[correlation.index]
}).reset_index(drop=True)
print(correlation_df)

# 输出最大的五部电影
top_5 = correlation_df.nlargest(5, '相关系数')
# print(top_5)



